import { Component, OnInit } from '@angular/core';
import { HealthQuotesService } from '../health-quotes/health-quotes.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-health-quotes',
  templateUrl: './health-quotes.component.html',
  styleUrls: ['./health-quotes.component.css']
})


export class HealthQuotesComponent implements OnInit {
  quotesArray: any;
  cLogo: any;
  pDetails: any;
  cId: any;
  pushAray: any = [];
  cardCompare: boolean = false;
  openEdit: boolean = false;
  hospitalcount: any = [];
  constructor(private healthquote: HealthQuotesService, private route: ActivatedRoute,
    private router: Router) { }
  storeParams;
  store: any = [];
  logo: any
  storequote: any;
  jsonObject: any;
  responsePlan: any = [];
  cashlessHospital: any = [];
  storepushedValue: any = [];
  storeemail: any;
  storegender: any;
  storecity: any;
  storestate: any;
  storemobile: any;
  sub: any;
  storeage: any;
  storepincode:any
  ngOnInit() {

    
    this.sub = this.route.queryParams.subscribe((params) => {
      console.log(params)
      this.storeParams = params['page'];
      this.storequote = params['quote'];
      this.storemobile = params['mobile'];
      this.storegender = params['gender'];
      this.storecity = params['city'];
      this.storestate = params['state'];
      this.storeemail = params['email'];
      this.storeage = params['age'];
      this.storepincode = params['pincode'];
      console.log(this.storeage)
      console.log(typeof (this.storeParams))
    });
    this.getHealthquotesData();
  }

  restorationchecked(value, checked) {
    console.log(value)

    if (value.target.checked == true) {
      this.quotesArray = this.quotesArray.filter((e, index) => {
        // if(e.SpecialFeatureLists[index] != undefined || e.SpecialFeatureLists[index] != null )
        // {
        for (var i = 0; i < e.SpecialFeatureLists.length; i++) {
          // if(e.SpecialFeatureLists[index].code == 'HF006'){
          //   return true;
          // }
          // }
          if (e.SpecialFeatureLists[i].code == 'HF006') {
            // console.log("hii")
            // if (e.SpecialFeatureLists[index].code == 'HF006') {
            return true;
          }
          else {
            return false
          }

        }

        //   else{
        //     return false
        //   // }
        // }
        // console.log(e);
        // console.log(e.SpecialFeatureLists[index - 3])
        // console.log(e.SpecialFeatureLists[index])
        console.log(index)
      })

      console.log(this.quotesArray)
      // this.quotesArray.map((e) => {
      //   // e.selectedcode = [];
      //   //  if( e.SpecialFeatureLists[i].code == 'HF006'){
      //   //           e.selectedcode.push(e.SpecialFeatureLists)

      //   //           console.log(e.selectedcode)

      //   //         }
      //   e.SpecialFeatureLists = e.SpecialFeatureLists.filter((ele) => {
      //     if (ele.code == 'HF006') {
      //       e.selectedcode.push(e.SpecialFeatureLists)
      //       console.log(e.SpecialFeatureLists)
      //       console.log(e.selectedcode)
      //     }
      //     else {
      //       // this.quotesArray.pop(e.SpecialFeatureLists)
      //     }
      //   })

      // })

    }
    // else {

    // }
  }

  compareCard(id) {
    console.log(id.CompanyDetails.logo, id.premiumDetails.finalPremium, id.productDetails.product_name)
    this.pushAray.push(id.CompanyDetails.logo, id.premiumDetails.finalPremium, id.productDetails.product_name);
    console.log(id.CompanyDetails.logo, id.premiumDetails.finalPremium, id.productDetails.product_name)
    console.log(this.pushAray)
    console.log(id)
    this.cardCompare = true;
    this.cLogo = id.CompanyDetails.logo
    this.cId = id.premiumDetails.finalPremium
    this.pDetails = id.productDetails.product_name
    //   for (var i = 0; i <= this.quotesArray.length; i++) {
    //     // if (e.target.checked == true){
    //     this.cardCompare = true;

    //     // }
    //   }
    // }
    // else {
    //   this.cardCompare = false;
    // }



  }




  getHealthquotesData() {
    let data = {
      "sum_insured": 500000,
      "quote_no": this.storequote,
      "module": "HealthPlans",
      "insurance_type": "Health Plans",
      "pincode": this.storepincode,
      "name": "Hfhhfnhjhnfhg",
      "email": this.storeemail,
      "mobile": this.storemobile,
      "city": this.storecity,
      "state": this.storestate,
      "source_url": "",
      "utm_source": "",
      "utm_medium": "",
      "utm_medium_m": "",
      "utm_medium_d": "",
      "utm_campaign": "",
      "utm_keyword": "",
      "status": 1,
      "cron_mail_status": 0,
      "cover": "1A3C",
      "adult": 1,
      "child": "3",

      "gender": this.storegender,
      "age": this.storeage,
      "dob_date": "",
      "dob_month": "",
      "dob_year": "",
      "term": 1,
      "requestTime": 1560424458,
      "header_code_id": 2,
      "header_code_desc": "Quotation Taken",
      "_csrfToken": ""

    }
    this.healthquote.gethealthQuotes(data).subscribe((res) => {

      this.quotesArray = res['results'].response;
      console.log(this.quotesArray)

      this.responsePlan = this.quotesArray.length

      // console.log(this.quotesArray.CashlessHospitalLists)

      // for (let i = 0; i<=this.quotesArray[i].CashlessHospitalLists.length; i ++){
      //   console.log(this.quotesArray[i].CashlessHospitalLists)
      //   this.cashlessHospital = this.quotesArray[i].CashlessHospitalLists;
      // this.hospitalcount = this.cashlessHospital.length
      // }


      this.quotesArray.map((e) => {
        this.cashlessHospital = e.CashlessHospitalLists
        console.log(this.cashlessHospital.length)
        console.log(this.cashlessHospital)
        this.hospitalcount = this.cashlessHospital.length
        console.log(this.hospitalcount)

        e.Cashlesslist = [];
        e.Cashlesslist.push(this.cashlessHospital)
        console.log(e.Cashlesslist)

        e.newCount = [];
        e.newCount.push(this.hospitalcount);





        e.newArray = [];
        // e.selectedcode = [];
        for (let i = 0; i < 4; i++) {
          e.newArray.push(e.SpecialFeatureLists[i])

          console.log(e.newArray)
        }
      })
      console.log(this.quotesArray)
      // console.log(res['results'].response[0].CompanyDetails)

      // this.store = e.SpecialFeatureLists;

      // console.log(e.SpecialFeatureLists)


      // let storepushed = [];
      // for (let i = 0; i <= this.store.length; i++) {
      // console.log(this.store[i])
      // storepushed = this.store[i]
      // storepushed.push(this.store[i])
      // for (let j = 0; j < 4; j++) {


      // }



      // }
      // this.storepushedValue = storepushed;
      // console.log(this.storepushedValue)


    }
    )

  }

  updateDetails(e) {
    // this.router.navigate(['/homemodule/one/edit'],{ queryParams: { quote : this.quote_no} });
    console.log(e)

    this.openEdit = true;

  }



}

