import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { EditService } from './edit.service';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-edit-info',
  templateUrl: './edit-info.component.html',
  styleUrls: ['./edit-info.component.css']
})
export class EditInfoComponent implements OnInit {
  updateForm: FormGroup;
  healthCover: string;
  sub:any =  [];
  constructor(private formBuilder: FormBuilder, private editServ: EditService,private route: ActivatedRoute) { }

  ngOnInit() {
    this.updateForm = this.formBuilder.group({
      age: ['', Validators.required],
      gender: ['', Validators.required],
      pincode: ['', Validators.required],
      adult: ['', Validators.required],
      child: ['', Validators.required],


    })
this.updateeditDetails();

    this.sub = this.route.queryParams.subscribe((params) => {
      console.log(params)
      // this.storeParams = params['page'];
      // console.log(this.storeParams)
      // console.log(typeof (this.storeParams))
    });
  }

  checkgender() {
    if (this.updateForm.get('adult').value == "one" && this.updateForm.get('child').value == 0) {
      // console.log(healthCover)
      this.healthCover = '1A';

    }
    else if (this.updateForm.get('adult').value == "two" && this.updateForm.get('child').value == 0) {


      this.healthCover = '2A';
    }

    else if (this.updateForm.get('adult').value == "one" && this.updateForm.get('child').value == 1) {


      this.healthCover = '1A1C';
    }

    else if (this.updateForm.get('adult').value == "two" && this.updateForm.get('child').value == 1) {


      this.healthCover = '2A1C';
    }


  }

  updateeditDetails() {
    this.checkgender();
    let data = {
      quote_no: "QB1513160284890469915",
      sum_insured: 400000,
      age: this.updateForm.get('age').value,
      city: "Delhi",
      state: "Delhi",
      term: 1,
      cover: this.healthCover,
      adult: this.updateForm.get('adult').value,
      child: this.updateForm.get('child').value,
      pincode: this.updateForm.get('pincode').value,
      healthGender: this.updateForm.get('gender').value, 
    }

    // if(this.updateForm.valid){
    this.editServ.updateHealthQuotes(data).subscribe((store)=>{
      console.log(store)
    })
  // }
  }



}
